<?php

/*
 Copyright (c) 2009 hamcrest.org
 */

class Hamcrest_AssertionError extends RuntimeException
{
}
